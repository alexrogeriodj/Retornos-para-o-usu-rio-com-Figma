export { default as About } from './About';
export { default as Details } from './Details';
export { default as FAQ } from './FAQ';
export { default as Rating } from './Rating';
