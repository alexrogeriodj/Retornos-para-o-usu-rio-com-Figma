/* eslint-disable import/prefer-default-export */
import styled from 'styled-components/native';

export const TextWrapper = styled.Text`
  font-size: 16px;
  line-height: 24px;
`;
