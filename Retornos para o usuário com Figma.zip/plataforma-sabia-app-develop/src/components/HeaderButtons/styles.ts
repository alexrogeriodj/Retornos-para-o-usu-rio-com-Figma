import styled from 'styled-components/native';

export const ButtonsHeaderWrapper = styled.View`
  flex-direction: row;
  margin-left: 0;
`;
