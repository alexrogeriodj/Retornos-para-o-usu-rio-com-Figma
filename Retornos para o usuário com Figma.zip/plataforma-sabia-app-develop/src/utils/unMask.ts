export const unMask = (field: string) => field.replace(/\D/g, '');
